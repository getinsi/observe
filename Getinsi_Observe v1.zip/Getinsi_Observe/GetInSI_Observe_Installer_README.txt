=====================================================
🛰️ GetInSI Observe – Free Edition | Installer Package
=====================================================

This installer deploys the Freemium version of GetInSI Observe:
a lightweight log forensic analysis tool for IT/OT environments.

✅ Includes:
- Log parser for syslog files (e.g. ASA `%ASA-4-106023`)
- Configuration file analyzer (routes, interfaces, overview)
- CSV export of results
- HTML interface (upload, results, overview)
- No external dependencies or internet required

📦 Installation Path:
    C:\Users\<yourname>\AppData\Local\Programs\GetInSI_Observe\

--------------------------------------------
🖥️ System Requirements
--------------------------------------------
- Windows 10 or later (x64)
- Python NOT required (compiled executable)
- No admin rights needed (runs as user)

--------------------------------------------
🚀 Installation Instructions
--------------------------------------------
1. Run:  `GetInSI_Observe_Installer.exe`
2. App installs silently to Programs folder
3. A shortcut will appear on Desktop: "GetInSI Observe"
4. It auto-launches: http://127.0.0.1:8000

--------------------------------------------
🧪 How to Use
--------------------------------------------
- Upload `.txt` logs → `/upload`
- View enriched events → `/results`
- Upload `.cfg` config files → view `/overview`, `/routes`, `/interfaces`

--------------------------------------------
📤 Export & Results
--------------------------------------------
- Results stored in `temp/*.json`
- Exportable as CSV from the interface

--------------------------------------------
📬 Support
--------------------------------------------
Contact: getinsitools@gmail.com
Website: https://getinsi.com